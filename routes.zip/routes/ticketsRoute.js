
// const express = require('express')
// const { getTicketBasedonId, updateTicketById } = require('../controllers/ticket')

// const router = express.Router()

// router.get('/get-ticket/:id',getTicketBasedonId)

// router.put('/update-ticket/:id',updateTicketById)

// // module.exports= routers